library(testthat)
library(cellranger)

test_check("cellranger")
