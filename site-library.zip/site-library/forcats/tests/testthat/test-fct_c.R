context("fct_c")

test_that("first argument can be factor or list of factors", {
  fs <- list(factor("a"), factor("b"))
  fab <- factor(c("a", "b"))

  expect_equal(fct_c(fs), fab)
  expect_equal(fct_c(fs[[1]], fs[[2]]), fab)
})

test_that("all inputs must be factors", {
  expect_error(fct_c("a"), "must be factors")
  expect_error(fct_c(list("a")), "must be factors")
})
